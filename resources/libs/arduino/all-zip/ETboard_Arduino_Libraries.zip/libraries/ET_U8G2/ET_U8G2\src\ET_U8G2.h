/********************************************************************************** 
 * Author       : SCS
 * Date         : 2018.09.30  
 * Modified     : 2022.10.03 : SCS : support arduino uno with ET-Upboard
 * Modified     : 2023.10.11 : SCS : decrease memory for arduino
 * Modified     : 2024.07.11 : SCS : add 5 line, 8 line
 * Modified     : 2024.07.19 : SCS : add setLine(int line, String buffer)
 * Modified     : 2024.07.21 : SCS : add two setLine()
 * Modified     : 2024.08.05 : SCS : rename ET_OLED to ET_U8G2 and make static library
**********************************************************************************/

#ifndef ET_U8G2_H
#define ET_U8G2_H

#include <Arduino.h>
#include <U8g2lib.h>                              //  2024.08.07 : SCS : 절대 지운면 안됨

class ET_U8G2 {
public:
  ET_U8G2();
  
  void setup(void);
  #if defined(ARDUINO_AVR_UNO)
  void clearDisplay();
  void display();
  #elif defined(ESP32)
  void display(int display_line = 3);  // 기본값을 3으로 설정
  #endif
  void setLine(int line, const char* buffer);
  void setLine(int line, const String& buffer);
  void setLine(int line, int buffer);
  void setLine(int line, float buffer, int decimal_point);

private:
  static const int MAX_LINES = 8;
  String lineString[MAX_LINES];
};

#endif // ET_U8G2_H

//=================================================================================
// End of Line
//=================================================================================
