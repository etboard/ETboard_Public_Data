/******************************************************************************************
 * FileName     : Analog.h
 * Description  : ETboard 기본 아날로그 센서
 * Author       : SCS
 * Created Date : 2024.08.11 : SCS
 * Reference    : 
 * Modified     : 
 * Modified     : 
******************************************************************************************/

#ifndef ANALOG_H
#define ANALOG_H

#include <Arduino.h>

class Analog {
private:
    uint8_t pin;
    int value;
    const int numReadings = 10;
    int readings[10];
    int readIndex = 0;
    int total = 0;

public:
    Analog(uint8_t analogPin);

    void update();
    int getValue();

    // 아날로그 핀 상수
    static const uint8_t A0 = 36;
    static const uint8_t A1 = 39;
    static const uint8_t A2 = 32;
    static const uint8_t A3 = 33;
    static const uint8_t A4 = 34;
    static const uint8_t A5 = 35;
    static const uint8_t A6 = 25;
    static const uint8_t A7 = 26;
};

#endif // ANALOG_H

//==========================================================================================
// End of Line
//==========================================================================================
