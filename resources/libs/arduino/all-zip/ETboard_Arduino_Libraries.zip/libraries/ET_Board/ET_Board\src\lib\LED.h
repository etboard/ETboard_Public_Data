/******************************************************************************************
 * FileName     : LED.h
 * Description  : ETboard 기본 LED 5개
 * Author       : SCS
 * Created Date : 2024.08.11
 * Reference    : 
 * Modified     : 
 * Modified     : 
******************************************************************************************/

#ifndef LED_H
#define LED_H

#include <Arduino.h>

class LED {
  private:
    uint8_t pin;
    bool state;
  
  public:
    LED(uint8_t p);
    void on();
    void off();
    void toggle();
    bool getState();

    // 내장 LED를 위한 정적 멤버
    static const uint8_t D2 = 27;   // Red LED
    static const uint8_t D3 = 14;   // Blue LED
    static const uint8_t D4 = 12;   // Green LED
    static const uint8_t D5 = 13;   // Yellow LED
    static const uint8_t BUILTIN = 5;  // LED_BUILTIN
};

#endif

//==========================================================================================
// End of Line
//==========================================================================================
