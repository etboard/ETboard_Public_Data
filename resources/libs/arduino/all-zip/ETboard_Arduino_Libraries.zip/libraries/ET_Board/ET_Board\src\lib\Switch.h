/******************************************************************************************
 * FileName     : Switch.cpp 
 * Description  : ETboard 기본 스위치 
 * Author       : SCS
 * Created Date : 2024.08.11
 * Reference    : 
 * Modified     : 
 * Modified     : 
******************************************************************************************/

#ifndef SWITCH_H
#define SWITCH_H

#include <Arduino.h>

class Switch {
private:
    int pin;
    bool lastState;
    bool currentState;
    unsigned long lastDebounceTime;
    unsigned long debounceDelay;
    bool clicked;
    bool lastReportedState;

public:
    Switch(int switchPin, unsigned long debounceDelayMs = 150);

    void update();
    bool isPressed();
    bool isReleased();
    bool isClicked();
    bool stateChanged();

    static const uint8_t D6 = 15;
    static const uint8_t D7 = 16;
    static const uint8_t D8 = 17;
    static const uint8_t D9 = 4;
};

#endif // SWITCH_H

//==========================================================================================
// End of Line
//==========================================================================================
