# ETboard 아두이노(Arduino) 라이브러리 묶음 패키지 v2025.05.13

이 패키지는 ETboard 하드웨어를 위한 모든 필수 Arduino 라이브러리를 포함하고 있습니다.

## 설치 방법

### 수동 설치
1. 이 패키지의 압축을 해제합니다.
2. 압축을 해제한 폴더 내의 모든 라이브러리 폴더를 Arduino 스케치 폴더의 `libraries` 폴더에 복사합니다.
   - Windows: `%USERPROFILE%\Documents\Arduino\libraries\`
   - Mac/Linux: `~/Documents/Arduino/libraries/`
3. Arduino IDE를 재시작합니다.

## 포함된 아두이노 라이브러리

No version information found. Using default values.
ETboard_Libraries: vlatest

## 문의사항

문제가 발생하거나 도움이 필요하면 GitHub 이슈 트래커를 이용해 주세요.
