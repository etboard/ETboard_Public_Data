/******************************************************************************************
 * FileName     : ET_IoT_App.h
 * Description  : ETboard IoT 응용 프로그램 구성
 * Author       : SCS
 * Created Date : 2022.08.08
 * Reference    : 
 * Modified     : 2024.08.05 : SCS : using ET_U8G2
 * Modified     : 2024.08.07 : SCS : rename function
 * Modified     : 2024.08.22 : SCS : subscribe_to_command
 * Modified     : 2024.08.23 : SCS : add send
******************************************************************************************/

#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/*
#include "lib/etboard_com.h"
#include "lib/etboard_simple_mqtt.h"
#include "lib/etboard_oled_u8g2.h"
#include "lib/etboard_wifi.h"
*/

#include "ET_U8G2.h"
#include "./lib/etboard_com.h"
#include "./lib/etboard_wifi.h"
#include "./lib/etboard_simple_mqtt.h"

extern const char* board_firmware_verion;
extern void et_setup();
extern void et_loop();
extern void et_long_periodic_process();
extern void et_short_periodic_process();

extern class ET_IoT_App app;

//------------------------------------------------------------------------------------------
// 메시지 송신 주기 : 주의!!!! 너무 빨리 또는 많이 보내면 서버에서 거부할 수 있음(Banned)
//------------------------------------------------------------------------------------------
#define LONG_INTERVAL  (1000 * 5)                 // 권장 5초 (단위: 초/1000)

//------------------------------------------------------------------------------------------
// 메시지 표시 주기
//------------------------------------------------------------------------------------------
#define SHORT_INTERVAL  (1000 * 1)                // 권장 1초 (단위: 초/1000)


//==========================================================================================
class ET_IoT_App 
//==========================================================================================
{

  private:      
  
  public:          
    unsigned lastLongMillis;
    unsigned lastShortMillis;
    String operation_mode = "automatic";
    bool bDigitalChanged = false;
    
    ET_U8G2 oled;
    ETBOARD_COM etboard;
    ETBOARD_SIMPLE_MQTT mqtt; 
    ETBOARD_WIFI wifi;   
    
    ET_IoT_App();
    void setup(void);    
    void fast_blink_led(void);
    void normal_blink_led(void); 
    void display_BI(void);

    void dg_Write(int pin, int value);
    void update_digital_value();
    bool isChanged_digital_value(void);
    void initailize_digital_value(void);
    int  dg_Read(int pin);

    // 2024.08.23 : SCS 
    void add_sensor_data(const char* key, float value);
    void add_sensor_data(const char* key, int value);
    void add_sensor_data(const char* key, const char* value);
    void add_sensor_data(const char* key, const String& value);  // String 버전 추가
    void send_sensor_data();

    // 2024.08.23 : SCS
    void send_data(const char* component);
    void send_data(const char* component, const char* key, int value);
    void send_data(const char* component, const char* key, const char* value);
    void send_data(const char* component, const char* key, const String& value);
    

    // 2024.08.22 : SCS
    void setup_recv_message(const String& command, void (*handler)(const String&));
    
};

#endif

//==========================================================================================
// End of Line
//==========================================================================================
