/******************************************************************************************
 * FileName     : ET_Board.h
 * Description  : ET_Board
 * Author       : SCS
 * Created Date : 2024.08.11
 * Reference    : 
 * Modified     : 
 * Modified     : 
******************************************************************************************/

#ifndef ET_BOARD_H
#define ET_BOARD_H

#include <Arduino.h>

// LED 초기화
#include "./lib/LED.h"
extern class LED red_led;
extern class LED blue_led;
extern class LED green_led;
extern class LED yellow_led;
extern class LED builtin_led;

// 스위치 초기화 
#include "./lib/SWITCH.h"
extern class Switch red_switch;
extern class Switch blue_switch;
extern class Switch green_switch;
extern class Switch yellow_switch;

// 새로운 배열 선언
extern Switch* switches[];
extern const int NUM_SWITCHES;

// 새로운 함수 선언
void update_Switches();

// 아날로그 센서 초기화
#include "./lib/Analog.h"
extern Analog vr_sensor;
extern Analog cds_sensor;
extern Analog temperature_sensor;
extern Analog A3_sensor;
extern Analog A4_sensor;
extern Analog A5_sensor;
extern Analog A6_sensor;
extern Analog A7_sensor;

void update_AnalogSensors();

#endif // ET_BOARD_H

//==========================================================================================
// End of Line
//==========================================================================================
