/******************************************************************************************
 * FileName     : ET_MAX9814.h
 * Description  : ET_MAX9814 사운드 센서
 * Author       : SCS
 * Created Date : 2024.07.21
 * Reference    : 
 * Modified     : 2024.08.04 : SCS : Make Static Library
 * Modified     : 
******************************************************************************************/

#ifndef ET_MAX9814_H
#define ET_MAX9814_H

#include <Arduino.h>

class ET_MAX9814 {
public:
    ET_MAX9814(int pin);
    void begin();
    void update();
    void reset();
    int getMaxSound() const;

private:
    int _pin;
    int _maxSound;
};

#endif // ET_MAX9814_H

//==========================================================================================
// End of Line
//==========================================================================================
